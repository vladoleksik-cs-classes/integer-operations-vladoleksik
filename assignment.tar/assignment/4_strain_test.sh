#!/bin/bash

rm reports/sanitize/report.json >/dev/null 2>&1

# Copy a set of input files to the current directory
cp grading/tests/1.in input.txt

# Run the executable for the stability test
./build/sanitized/main.exe

if [ $? -ne 0 ]; then
    ./sanitize-parser ./reports/sanitize/report.json main.cpp > reports/aggregated/sanitize.json
else
    echo "[]" > reports/aggregated/sanitize.json
fi

rm input.txt >/dev/null 2>&1
